import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# Load df
df = pd.read_csv('streamlit_data.csv')

# Function to clean and preprocess data
def preprocess_data(df):
    # Extract year and month from 'Premiere'
    netflix_date = df[['Premiere']].dropna()
    netflix_date['year'] = netflix_date['Premiere'].apply(lambda x: x.split(', ')[-1])
    netflix_date['month'] = netflix_date['Premiere'].apply(lambda x: x.lstrip().split(' ')[0])

    # Convert runtime columns to numeric
    df['Average_Runtime (min)'] = pd.to_numeric(df['Average_Runtime (min)'], errors='coerce')
    df['Runtime_min (min)'] = pd.to_numeric(df['Runtime_min (min)'], errors='coerce')
    df['Runtime_max (min)'] = pd.to_numeric(df['Runtime_max (min)'], errors='coerce')
    
    return df

df = preprocess_data(df)

# Function to create a pie chart using matplotlib
def plot_pie_chart(data, title):
    fig, ax = plt.subplots()
    ax.pie(data, labels=data.index, autopct='%1.1f%%', startangle=90)
    ax.set_title(title)
    st.pyplot(fig)

# Function to create a histogram using matplotlib
def plot_histogram(data, title):
    fig, ax = plt.subplots()
    ax.hist(data, bins=20, color='skyblue', edgecolor='black')
    ax.set_title(title)
    ax.set_xlabel('Average Runtime (minutes)')
    ax.set_ylabel('Frequency')
    st.pyplot(fig)

# Streamlit app
st.title('Netflix programming dashboard')

# Sidebar for user input
st.sidebar.header('Filters')

# Interactive Filters
year = st.sidebar.slider('Select Year', min_value=int(df['Release_year'].min()), max_value=int(df['Release_year'].max()), value=int(df['Release_year'].max()))
selected_genre = st.sidebar.selectbox('Select Genre', options=['All'] + list(df['Genre'].unique()))
selected_language = st.sidebar.selectbox('Select Language', options=['All'] + list(df['Language'].unique()))
min_runtime, max_runtime = st.sidebar.slider('Select Runtime Range (min)', min_value=int(df['Runtime_min (min)'].min()), max_value=int(df['Runtime_max (min)'].max()), value=(int(df['Runtime_min (min)'].min()), int(df['Runtime_max (min)'].max())))

# Filter data based on user inputs
filtered_df = df.copy()
if selected_genre != 'All':
    filtered_df = filtered_df[filtered_df['Genre'] == selected_genre]
if selected_language != 'All':
    filtered_df = filtered_df[filtered_df['Language'] == selected_language]
filtered_df = filtered_df[(filtered_df['Runtime_min (min)'] >= min_runtime) & (filtered_df['Runtime_max (min)'] <= max_runtime)]
filtered_df = filtered_df[filtered_df['Release_year'] == year]

# Display key metrics
st.subheader('About your choices')
st.write(f"Number of Shows: {len(filtered_df)}")
st.write(f"Average Runtime: {filtered_df['Average_Runtime (min)'].mean():.2f} minutes")
st.write(f"Average Number of Seasons: {filtered_df['Seasons'].mean():.2f}")
st.write(f"Average Total Episodes: {filtered_df['Total episodes'].mean():.2f}")

# Create and display visualizations
st.subheader('Visualizations')

# Genre Distribution Pie Chart
st.subheader('Genre distribution')
genre_counts = filtered_df['Genre'].value_counts()
plot_pie_chart(genre_counts, 'Genre distribution')

# Language Distribution Pie Chart
st.subheader('Language distribution')
language_counts = filtered_df['Language'].value_counts()
plot_pie_chart(language_counts, 'Language distribution')

# Average Runtime Histogram
st.subheader('Distribution of average runtime')
plot_histogram(filtered_df['Average_Runtime (min)'].dropna(), 'Distribution of average runtime')

# Shows with Minimum Runtime
st.subheader('Top 15 shows with minimum runtime')
top_15_min = filtered_df.sort_values(by='Runtime_min (min)', ascending=True).head(15)
fig, ax = plt.subplots()
top_15_min.plot(kind='barh', x='Title', y='Runtime_min (min)', ax=ax, color='skyblue', legend=False)
ax.set_title('Top 15 shows with minimum runtime')
ax.set_xlabel('Runtime (minutes)')
ax.set_ylabel('Show title')
ax.invert_yaxis()  # Invert y-axis to have the highest values on top
for i in ax.patches:
    ax.text(i.get_width() + 0.5, i.get_y() + i.get_height()/2, f'{i.get_width():.1f}', va='center')
st.pyplot(fig)

# Shows with Maximum Runtime
st.subheader('Top 15 shows with maximum runtime')
top_15_max = filtered_df.sort_values(by='Runtime_max (min)', ascending=False).head(15)
fig, ax = plt.subplots()
top_15_max.plot(kind='barh', x='Title', y='Runtime_max (min)', ax=ax, color='skyblue', legend=False)
ax.set_title('Top 15 shows with maximum runtime')
ax.set_xlabel('Runtime (minutes)')
ax.set_ylabel('Show title')
ax.invert_yaxis()  # Invert y-axis to have the highest values on top
for i in ax.patches:
    ax.text(i.get_width() + 0.5, i.get_y() + i.get_height()/2, f'{i.get_width():.1f}', va='center')
st.pyplot(fig)